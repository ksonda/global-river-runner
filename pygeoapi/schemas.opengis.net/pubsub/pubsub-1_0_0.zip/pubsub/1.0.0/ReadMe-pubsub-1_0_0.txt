OGC(r) Publish/Subscribe (PubSub) Interface Standard schema - ReadMe.txt
=======================================================================

More information may be found at
 http://www.opengeospatial.org/standards/pubsub

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2016-08-10  Aaron Braeckel, Lorenzo Bigagli, Johannes Echterhoff
  * v1.0: Published 1.0.0 from OGC 13-131r1.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2016 Open Geospatial Consortium.

-----------------------------------------------------------------------
