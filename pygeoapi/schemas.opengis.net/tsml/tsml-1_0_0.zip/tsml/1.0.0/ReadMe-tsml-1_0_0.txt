OGC(r) TimeseriesML (TSML) schema - ReadMe.txt
=======================================================================

TimeseriesML 1.0 - XML Encoding of the Timeseries Profile of Observations and Measurements

More information may be found at
 http://www.opengeospatial.org/standards/tsml

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2016-08-19  James Tomkins, Dominic Lowe
  * v1.0: Published 1.0.0 from OGC 15-042r3.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2015, 2016 Open Geospatial Consortium.

-----------------------------------------------------------------------
