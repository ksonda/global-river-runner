OGC(r) OGC API - Features ReadMe.txt
==================================

OGC(r) OGC API - Features
-----------------------------------------------------------------------

OGC API - Features

More information may be found at
 http://www.opengeospatial.org/standards/ogcapi-features

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/ogcapi/features/

-----------------------------------------------------------------------

2019-10-11  Clemens Portele
  + v1.0: Added OGC API - Features - Part 1: Core 1.0 as ogcapi/features/1.0 from OGC 17-069r3

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2019 Open Geospatial Consortium.

-----------------------------------------------------------------------

