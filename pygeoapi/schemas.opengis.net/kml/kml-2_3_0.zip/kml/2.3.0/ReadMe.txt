OGC(r) KML 2.3 - ReadMe.txt
=======================================================================

The OGC KML standard is described in the document OGC 12-007r2 at
 http://www.opengeospatial.org/standards/kml

-----------------------------------------------------------------------

2015-10-22  
  + v2.3: Added KML 2.3.0 as KML/2.3 from OGC 12-007r2.

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of the Open Geospatial Consortium.

Copyright (c) 2015 Open Geospatial Consortium.

-----------------------------------------------------------------------
