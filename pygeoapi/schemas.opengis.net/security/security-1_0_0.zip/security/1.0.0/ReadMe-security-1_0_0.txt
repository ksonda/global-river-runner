OGC(r) Web Services Security schema ReadMe.txt
==================================

OGC(r) Web Services Security (OWS Security) Standard

More information may be found at
 http://www.opengeospatial.org/standards/security

The most current schema are available at
http://schemas.opengis.net/security/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

-----------------------------------------------------------------------


2019-02-07  OWS Common Security SWG
  + v1.0: published OWS Security 1.0.0 as security/1.0 from OGC 17-007r1

 Note: Check each OGC numbered document for detailed changes.


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2018-2019 Open Geospatial Consortium.

-----------------------------------------------------------------------

