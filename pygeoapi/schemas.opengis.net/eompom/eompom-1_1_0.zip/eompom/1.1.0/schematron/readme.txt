The file schematron_rules_for_eom-eop.sch is identical to schematron_rules_for_eop.sch but 
contains the phase definitions that are required to execute the schematron using OGC Team Engine.

The schematron_skeleton_for_eop.xsl transforms the schematron .sch file into XSLT.