OpenGIS(r) OSEO schema - ReadMe.txt
======================================================

OGC(r) Ordering Services For Earth Observation Products 1.0
-----------------------------------------------------------------------

Ordering Services For Earth Observation Products is an OGC Standard.

The Ordering Services For Earth Observation Products is defined in
OGC document 06-141r6.

More information may be found at
 http://www.opengeospatial.org/standards/oseo

The most current schema are available at http://schemas.opengis.net/ .

The root (all-components) XML Schema Document, which includes
directly and indirectly all the XML Schema Documents, defined by
Ordering Service 1.0 is oseo.xsd.

* Latest version is: http://schemas.opengis.net/oseo/1.0/oseo.xsd *

-----------------------------------------------------------------------

2012-07-21  Kevin Stegemoller
  * v1.0.0: Copyright updates

2011-12-20  Daniele Marchionni
  * v1.0.0: Added oseo/1.0 - OGC 06-141r6

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2011 Open Geospatial Consortium.

-----------------------------------------------------------------------

