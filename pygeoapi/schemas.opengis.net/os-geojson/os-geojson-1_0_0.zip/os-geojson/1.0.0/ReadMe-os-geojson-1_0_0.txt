OGC(r) os-geojson schema ReadMe.txt
==================================

OGC(r) OpenSearch EO GeoJson(_LD) Respaonce Encoding Standard (os-geojson)
-----------------------------------------------------------------------

More information may be found at
 http://www.opengeospatial.org/standards/os-geojson

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

* Latest version is: http://schemas.opengis.net/os-geojson/1.0/ *

-----------------------------------------------------------------------

2020-05-07  Yves Coene
  + v1.0: Added os-geojson 1.0 as os-geojson/1.0 from OGC 17-047r1

 Note: Check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of Open Geospatial Consortium.

Copyright (c) 2020 Open Geospatial Consortium.

-----------------------------------------------------------------------

