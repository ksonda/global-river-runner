These Schematron rules provide additional conformance checks on coverage instance documents, beyond the capabilities of XML Schema. However, this still does not capture all conformance checks established in the Abstract Test Suite (ATS); these additional checks are implemented directly in CTL (Conformance Test Language) of the OGC TEAM Engine on which the overall conformance test is implemented by OGC.

Last updated: 2012-Jun-30
Copyright (c) 2012 Open Geospatial Consortium.
To obtain additional rights of use, visit http://www.opengeospatial.org/legal/.

