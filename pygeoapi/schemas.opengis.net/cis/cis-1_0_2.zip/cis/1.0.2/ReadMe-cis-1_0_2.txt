-----------------------------------------------------------------------
OGC(r) Web Coverage Service Interface Standard – ReadMe.txt
-----------------------------------------------------------------------

More information on the OGC Web Coverage Service Interface schema standard
may be found at
 http://www.opengeospatial.org/standards/wcs

The most current schema is available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

Change history:

2017-01-16 Peter Baumann
  * v1.0: renamed gmlcov 1.0.2 as cis/1.0 (OGC 13-057r1)
    No modifications.

Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2017 Open Geospatial Consortium.

-----------------------------------------------------------------------

