This directory contains the example coverage files from GMLCOV/CIS 1.0.
The only change is that the GML namespace of CIS 1.1 has been added in the text files.
Purpose of these files is to demonstrate backwards compatibility of CIS 1.1.

