OGC(r) Catalogue Services Schema - ReadMe.txt
=======================================================================

OGC Catalogue Services Standard
-----------------------------------------------------------------------

OGC Catalogue Service Implementation Standard

More information may be found at
 http://www.opengeospatial.org/standards/cat

The most current schema are available at http://schemas.opengis.net/
and all OGC schemas may be downloaded in a complete bundle from
http://schemas.opengis.net/SCHEMAS_OPENGIS_NET.zip

-----------------------------------------------------------------------

2016-06-10 
  *  v1.1: Post Cat CSW 3.0.0 as cat/csw/3.0 (OGC 12-176r7)

 Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

OGC and OpenGIS are registered trademarks of the Open Geospatial Consortium.

Copyright (c) 2016 Open Geospatial Consortium.

-----------------------------------------------------------------------

